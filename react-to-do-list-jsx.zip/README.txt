A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/GQrZzm.

 Example of using JSX in the JS panel on CodePen